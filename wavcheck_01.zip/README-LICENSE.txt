wavcheck by Mike Simpson is licensed under a
Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.

More detail can be found here:

http://creativecommons.org/licenses/by-nc-sa/3.0/